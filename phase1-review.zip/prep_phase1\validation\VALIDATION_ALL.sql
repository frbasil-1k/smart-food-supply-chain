-- ============================================================================
-- VALIDATION_ALL.sql   —   post-migration verification
-- READ-ONLY except for the clearly marked negative probes, which are DEV-ONLY
-- and are commented out. Every block states its expected result.
--
-- Run the block for a migration immediately after that migration, then run
-- `python database/audit_db.py`. Save both outputs with the migration record.
-- ============================================================================


-- ===========================================================================
-- V000 — batch-level invariants (run after every migration)
-- ===========================================================================
-- Data preservation: these must still total 104 with identical per-table counts.
SELECT 'organization' AS t, COUNT(*) AS n FROM organization
UNION ALL SELECT 'branch',           COUNT(*) FROM branch
UNION ALL SELECT 'app_user',         COUNT(*) FROM app_user
UNION ALL SELECT 'route',            COUNT(*) FROM route
UNION ALL SELECT 'coverage_area',    COUNT(*) FROM coverage_area
UNION ALL SELECT 'route_assignment', COUNT(*) FROM route_assignment
UNION ALL SELECT 'donation',         COUNT(*) FROM donation
UNION ALL SELECT 'food_category',    COUNT(*) FROM food_category
UNION ALL SELECT 'donation_item',    COUNT(*) FROM donation_item
UNION ALL SELECT 'inspection_log',   COUNT(*) FROM inspection_log
UNION ALL SELECT 'dependent',        COUNT(*) FROM dependent
UNION ALL SELECT 'delivery',         COUNT(*) FROM delivery
UNION ALL SELECT 'delivery_item',    COUNT(*) FROM delivery_item
UNION ALL SELECT 'spoilage_record',  COUNT(*) FROM spoilage_record
UNION ALL SELECT 'delivery_review',  COUNT(*) FROM delivery_review;

-- Content fingerprint: must equal the pre-migration values from 000 P9.
SELECT COALESCE(SUM(quantity_kg), 0) AS item_total_kg,
       COALESCE(SUM(ROUND(quantity_kg * 100)), 0) AS item_total_centikg
  FROM donation_item;


-- ===========================================================================
-- V001 — USER_CREDENTIAL
-- ===========================================================================
-- V001-A structure: 11 columns, PK on user_id, unique reset index, one FK.
SELECT COUNT(*) AS columns_present FROM information_schema.columns
 WHERE table_schema = DATABASE() AND table_name = 'user_credential';
-- expect 11

SELECT index_name, non_unique, GROUP_CONCAT(column_name ORDER BY seq_in_index) AS cols
  FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'user_credential'
 GROUP BY index_name, non_unique;
-- expect PRIMARY(user_id) and uq_cred_reset_token(reset_token_hash, unique)

-- V001-B no credentials were invented for existing users.
SELECT COUNT(*) AS credential_rows FROM user_credential;
-- expect 0

SELECT COUNT(*) AS users_without_credential
  FROM app_user u LEFT JOIN user_credential c USING (user_id)
 WHERE c.user_id IS NULL;
-- expect 15

-- V001-C no plaintext-looking value (hash prefix check; the audit has the same
-- check as an INVARIANT and it must stay at 0).
SELECT COUNT(*) AS non_scrypt_hashes FROM user_credential
 WHERE password_hash NOT LIKE 'scrypt:%';
-- expect 0

-- V001-D lock consistency (also enforced by chk_cred_lock_consistency).
SELECT COUNT(*) AS incoherent_locks FROM user_credential
 WHERE locked_until IS NOT NULL AND failed_attempts = 0;
-- expect 0

-- V001-E (DEV ONLY) FK rejects an unknown user; expect 1452.
-- INSERT INTO user_credential (user_id, password_hash)
-- VALUES (999999, REPEAT('x', 60));


-- ===========================================================================
-- V002 — DONATION_STATUS_HISTORY
-- ===========================================================================
SELECT COUNT(*) AS history_rows FROM donation_status_history;
-- expect 5 immediately after the migration

SELECT COUNT(*) AS donations_without_history
  FROM donation d
 WHERE NOT EXISTS (SELECT 1 FROM donation_status_history h
                    WHERE h.donation_id = d.donation_id);
-- expect 0

SELECT COUNT(*) AS fabricated_legacy_timestamps
  FROM donation_status_history
 WHERE is_reconstructed = 1 AND changed_at IS NOT NULL;
-- expect 0  (and the CHECK makes this unstorable)

SELECT COUNT(*) AS genuine_rows_without_timestamp
  FROM donation_status_history
 WHERE is_reconstructed = 0 AND changed_at IS NULL;
-- expect 0

SELECT COUNT(*) AS legacy_snapshots_with_actor
  FROM donation_status_history
 WHERE is_reconstructed = 1 AND changed_by_user_id IS NOT NULL;
-- expect 0

SELECT donation_id, COUNT(*) AS snapshots
  FROM donation_status_history
 WHERE is_reconstructed = 1
 GROUP BY donation_id HAVING COUNT(*) > 1;
-- expect 0 rows

SELECT to_status, COUNT(*) AS snapshots
  FROM donation_status_history GROUP BY to_status;
-- expect COMPLETED 4, APPROVED 1

-- V002-F (DEV ONLY) a faked legacy timestamp must be rejected with 3819.
-- INSERT INTO donation_status_history
--   (donation_id, from_status, to_status, changed_at, is_reconstructed)
-- VALUES (1, NULL, 'PENDING', NOW(), 1);


-- ===========================================================================
-- V003 — DONATION pickup columns
-- ===========================================================================
SELECT column_name, column_type, is_nullable, column_default
  FROM information_schema.columns
 WHERE table_schema = DATABASE() AND table_name = 'donation'
   AND column_name IN ('pickup_address', 'pickup_pincode', 'pickup_contact')
 ORDER BY ordinal_position;
-- expect varchar(255)/varchar(10)/varchar(15), all YES, all NULL

SELECT COUNT(*) AS donations_without_pickup_address FROM donation WHERE pickup_address IS NULL;
SELECT COUNT(*) AS donations_without_pickup_pincode FROM donation WHERE pickup_pincode IS NULL;
SELECT COUNT(*) AS donations_without_pickup_contact FROM donation WHERE pickup_contact IS NULL;
-- expect 5 / 5 / 5 immediately after the migration: legacy rows stay NULL

-- After go-live: format sanity as OBSERVATIONS, never as a hard failure.
SELECT COUNT(*) AS pincode_format_suspects FROM donation
 WHERE pickup_pincode IS NOT NULL AND pickup_pincode NOT REGEXP '^[1-9][0-9]{5}$';
SELECT COUNT(*) AS contact_format_suspects FROM donation
 WHERE pickup_contact IS NOT NULL AND pickup_contact NOT REGEXP '^\\+91[6-9][0-9]{9}$';
-- expect 0 once the API validates; investigate any growth


-- ===========================================================================
-- V004 — DELIVERY driver attribution
-- ===========================================================================
SELECT column_name, column_type, is_nullable, column_default
  FROM information_schema.columns
 WHERE table_schema = DATABASE() AND table_name = 'delivery'
   AND column_name IN ('driver_user_id', 'scheduled_for')
 ORDER BY ordinal_position;
-- expect int/NULL and datetime/NULL, both nullable, no default

SELECT COUNT(*) AS deliveries_without_driver FROM delivery WHERE driver_user_id IS NULL;
SELECT COUNT(*) AS deliveries_without_schedule FROM delivery WHERE scheduled_for IS NULL;
-- expect 5 / 5 immediately after the migration (no backfill, by design)

SELECT COUNT(*) AS drivers_with_invalid_role
  FROM delivery d JOIN app_user u ON u.user_id = d.driver_user_id
 WHERE u.user_role <> 'DRIVER';
-- expect 0

SELECT COUNT(*) AS active_rows_without_driver
  FROM delivery
 WHERE delivery_status IN ('IN_TRANSIT')
   AND driver_user_id IS NULL;
-- expect 0 for any delivery created after go-live

SELECT trigger_name, action_timing, event_manipulation, event_object_table
  FROM information_schema.triggers
 WHERE trigger_schema = DATABASE()
   AND trigger_name IN ('trg_delivery_driver_insert', 'trg_delivery_driver_update');
-- expect 2 rows: BEFORE INSERT, BEFORE UPDATE, delivery

-- Splitting one donation across the same branch twice must remain possible.
SELECT donation_id, recipient_branch_id, COUNT(*) AS deliveries
  FROM delivery GROUP BY donation_id, recipient_branch_id HAVING COUNT(*) > 1;
-- expect 0 rows today, and NO unique constraint should exist on the pair:
SELECT COUNT(*) AS blocking_unique_index FROM information_schema.statistics
 WHERE table_schema = DATABASE() AND table_name = 'delivery'
   AND non_unique = 0 AND index_name <> 'PRIMARY';
-- expect 0

-- V004-F (DEV ONLY) role gate; expect 1644.
-- UPDATE delivery SET driver_user_id = (SELECT user_id FROM app_user
--   WHERE user_role = 'NGO_MANAGER' LIMIT 1) WHERE delivery_id = 1;


-- ===========================================================================
-- V005 — DONATION_ITEM quantity guard
-- ===========================================================================
SELECT trigger_name, action_timing, event_manipulation
  FROM information_schema.triggers
 WHERE trigger_schema = DATABASE()
   AND trigger_name = 'trg_donation_item_quantity_update';
-- expect BEFORE UPDATE

-- No item may currently violate the invariant the guard protects.
SELECT COUNT(*) AS over_allocated_items FROM donation_item di
 WHERE di.quantity_kg <
       COALESCE((SELECT SUM(quantity_delivered_kg) FROM delivery_item
                  WHERE food_item_id = di.food_item_id), 0) +
       COALESCE((SELECT SUM(quantity_spoiled_kg) FROM spoilage_record
                  WHERE food_item_id = di.food_item_id), 0);
-- expect 0

-- V005-B/C (DEV ONLY) increase and exact-limit reduction should succeed.
-- V005-D (DEV ONLY) reduction below delivered+spoiled should fail with 1644.


-- ===========================================================================
-- V006 — temperature plausibility CHECK
-- ===========================================================================
SELECT tc.constraint_name, tc.enforced, cc.check_clause
  FROM information_schema.table_constraints tc
  JOIN information_schema.check_constraints cc
    ON cc.constraint_schema = tc.constraint_schema
   AND cc.constraint_name   = tc.constraint_name
 WHERE tc.table_schema = DATABASE() AND tc.constraint_name = 'chk_temperature_range';
-- expect ENFORCED=YES and the -50/150 clause

SELECT COUNT(*) AS out_of_band_readings FROM inspection_log
 WHERE temperature_c IS NOT NULL AND (temperature_c < -50 OR temperature_c > 150);
-- expect 0

SELECT COUNT(*) AS null_readings FROM inspection_log WHERE temperature_c IS NULL;
-- expect unchanged from preflight (NULL remains legal)


-- ===========================================================================
-- V007 — vw_donor_impact
-- ===========================================================================
SELECT COUNT(*) AS view_present FROM information_schema.views
 WHERE table_schema = DATABASE() AND table_name = 'vw_donor_impact';
-- expect 1

SELECT COUNT(*) AS original_view_still_present FROM information_schema.views
 WHERE table_schema = DATABASE() AND table_name = 'vw_donor_sustainability';
-- expect 1

SELECT COUNT(*) AS negative_balance_donors FROM vw_donor_impact
 WHERE undistributed_balance_kg < 0;
-- expect 0

SELECT COUNT(*) AS delivered_exceeds_donated FROM vw_donor_impact
 WHERE delivered_kg > total_donated_kg;
-- expect 0

SELECT COUNT(*) AS donor_rows FROM vw_donor_impact;
-- expect 4 (the four DONOR accounts)

SELECT donor_name, total_donated_kg, delivered_kg, spoiled_kg, undistributed_balance_kg
  FROM vw_donor_impact ORDER BY delivered_kg DESC;
-- REVIEW GATE: read this output before relying on the view.
