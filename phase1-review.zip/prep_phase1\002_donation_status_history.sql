-- ============================================================================
-- 002_donation_status_history.sql   —   F2: truthful donation lifecycle
-- DRAFT — UNEXECUTED. Do not run outside the approved migration batch.
--
-- Creates one table and inserts one RECONSTRUCTED snapshot row per existing
-- donation. DONATION itself is read, never written.
--
-- PRECONDITION (run and require 0 rows):
--   SELECT table_name FROM information_schema.tables
--    WHERE table_schema = DATABASE() AND table_name = 'donation_status_history';
-- ============================================================================

CREATE TABLE `donation_status_history` (
  `history_id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `donation_id`        INT             NOT NULL,
  `from_status`        ENUM('PENDING','SCHEDULED','COLLECTED','APPROVED',
                            'REJECTED','PARTIALLY_DISTRIBUTED','COMPLETED',
                            'CANCELLED') NULL DEFAULT NULL
                       COMMENT 'NULL means "no previous state on record": creation, or legacy snapshot',
  `to_status`          ENUM('PENDING','SCHEDULED','COLLECTED','APPROVED',
                            'REJECTED','PARTIALLY_DISTRIBUTED','COMPLETED',
                            'CANCELLED') NOT NULL,
  `changed_by_user_id` INT             NULL DEFAULT NULL
                       COMMENT 'Actor for genuine transitions; NULL for legacy snapshots',
  `changed_at`         DATETIME        NULL DEFAULT NULL
                       COMMENT 'Real event time. NULL only for reconstructed rows.',
  `is_reconstructed`   TINYINT(1)      NOT NULL DEFAULT 0
                       COMMENT '1 = baseline captured at migration time, not a real transition',
  `note`               VARCHAR(255)    NULL DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `idx_dsh_donation_time` (`donation_id`, `changed_at`, `history_id`),
  KEY `fk_dsh_user` (`changed_by_user_id`),
  CONSTRAINT `fk_dsh_donation` FOREIGN KEY (`donation_id`)
    REFERENCES `donation` (`donation_id`),
  CONSTRAINT `fk_dsh_user` FOREIGN KEY (`changed_by_user_id`)
    REFERENCES `app_user` (`user_id`),
  CONSTRAINT `chk_dsh_time_semantics` CHECK (
       (`is_reconstructed` = 0 AND `changed_at` IS NOT NULL)
    OR (`is_reconstructed` = 1 AND `changed_at` IS NULL)
  ),
  CONSTRAINT `chk_dsh_distinct_status` CHECK (
       `from_status` IS NULL OR `from_status` <> `to_status`
  ),
  CONSTRAINT `chk_dsh_reconstructed_no_actor` CHECK (
       `is_reconstructed` = 0 OR `changed_by_user_id` IS NULL
  )
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci
  COMMENT='Append-only donation status transitions; legacy rows are marked reconstructed';

-- ---------------------------------------------------------------------------
-- Legacy baseline: ONE snapshot per donation, no invented time, no actor
-- ---------------------------------------------------------------------------
INSERT INTO `donation_status_history`
      (`donation_id`, `from_status`, `to_status`, `changed_by_user_id`,
       `changed_at`, `is_reconstructed`, `note`)
SELECT d.`donation_id`,
       NULL,
       d.`donation_status`,
       NULL,
       NULL,
       1,
       'State observed when history began; earlier transitions were never recorded'
  FROM `donation` d
 WHERE NOT EXISTS (SELECT 1 FROM `donation_status_history` h
                    WHERE h.`donation_id` = d.`donation_id`);

-- Expected on the verified baseline: 5 rows (4 COMPLETED, 1 APPROVED).
-- The WHERE NOT EXISTS makes a re-run a no-op instead of creating duplicates.

-- ---------------------------------------------------------------------------
-- Why this is honest
-- ---------------------------------------------------------------------------
-- * `changed_at = NULL` is not a missing value to be filled in later: the
--   CHECK constraint makes it impossible to attach a guessed timestamp to a
--   reconstructed row. A fabricated date is a constraint violation, not a
--   style issue.
-- * `from_status = NULL` + `to_status = current` says exactly what is known:
--   "at migration time this donation was in this state". It does not claim the
--   donation passed through the earlier states in this database.
-- * The UI renders this single node as "Current state — captured when history
--   began <applied_at>", hollow, with no time column, plus the sentence
--   "Earlier transitions were not recorded."
-- * Real facts that DO exist are shown from their own columns, each labelled
--   for what it is: `donation.pickup_datetime` = "pickup scheduled for",
--   `inspection_log.inspected_at`, `delivery.delivered_at`,
--   `delivery_review.review_date`, `spoilage_record.reported_at`.
--   `pickup_datetime` is never relabelled as "collected at".
--
-- ---------------------------------------------------------------------------
-- How the application writes history (transactional rule)
-- ---------------------------------------------------------------------------
-- Exactly one function, `donation_service.change_status(donation_id, new_status,
-- actor_user_id, note)`, inside one transaction:
--   1. SELECT donation_id, donation_status FROM donation
--        WHERE donation_id = :id FOR UPDATE;          -- serialises transitions
--   2. validate the transition against the state machine (see below)
--   3. UPDATE donation SET donation_status = :new WHERE donation_id = :id;
--   4. INSERT INTO donation_status_history
--        (donation_id, from_status, to_status, changed_by_user_id, changed_at,
--         is_reconstructed, note)
--      VALUES (:id, :old, :new, :actor, NOW(), 0, :note);
--   5. COMMIT;  (any failure rolls both statements back together)
-- A trigger is deliberately not used: a trigger cannot know the acting user,
-- and a NULL actor on a genuine transition would be a lie. The cost is that a
-- manual UPDATE by a DBA bypasses history; the audit check `history_status_lag`
-- (see MIGRATION_PLAN.md §7) detects exactly that drift.
--
-- State machine (service layer, not encoded in the table):
--   PENDING    -> SCHEDULED | CANCELLED
--   SCHEDULED  -> COLLECTED | CANCELLED
--   COLLECTED  -> APPROVED | REJECTED
--   APPROVED   -> PARTIALLY_DISTRIBUTED | COMPLETED
--   PARTIALLY_DISTRIBUTED -> COMPLETED
--   REJECTED, COMPLETED, CANCELLED -> terminal
--   APPROVED additionally requires the latest inspection to be PASSED.
--
-- ---------------------------------------------------------------------------
-- Validation after applying (read-only)
-- ---------------------------------------------------------------------------
-- V002-A  every donation has at least one history row        -- expect 0 missing
-- V002-B  reconstructed rows with a timestamp                -- expect 0
-- V002-C  genuine rows without a timestamp                   -- expect 0
-- V002-D  one reconstructed row per donation, not several     -- expect 0
-- V002-E  SELECT COUNT(*) FROM donation_status_history;       -- expect 5
-- V002-F  the CHECK rejects a faked legacy timestamp:
--         INSERT INTO donation_status_history
--           (donation_id, from_status, to_status, changed_at, is_reconstructed)
--         VALUES (1, NULL, 'PENDING', NOW(), 1);              -- expect 3819
--
-- ---------------------------------------------------------------------------
-- Rollback
-- ---------------------------------------------------------------------------
-- DROP TABLE `donation_status_history`;
-- Fully reverses the structure. Once the application has written genuine
-- transitions the table holds unique history that exists nowhere else: dropping
-- it is DATA LOSS and must be replaced by a forward fix wherever possible.
