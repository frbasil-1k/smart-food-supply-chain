-- ============================================================================
-- 005_donation_item_quantity_guard.sql   —   F5: the denominator cannot shrink
-- DRAFT — UNEXECUTED. Do not run outside the approved migration batch.
--
-- One BEFORE UPDATE trigger on DONATION_ITEM. No column changes, no data change.
--
-- PRECONDITION (require 0 rows):
--   SELECT trigger_name FROM information_schema.triggers
--    WHERE trigger_schema = DATABASE()
--      AND trigger_name = 'trg_donation_item_quantity_update';
--   SELECT COUNT(*) FROM donation_item di WHERE di.quantity_kg <
--       COALESCE((SELECT SUM(quantity_delivered_kg) FROM delivery_item
--                  WHERE food_item_id = di.food_item_id),0) +
--       COALESCE((SELECT SUM(quantity_spoiled_kg)  FROM spoilage_record
--                  WHERE food_item_id = di.food_item_id),0);   -- must be 0
-- ============================================================================

DELIMITER ;;

CREATE TRIGGER `trg_donation_item_quantity_update`
BEFORE UPDATE ON `donation_item`
FOR EACH ROW
BEGIN
  -- DECIMAL(20,2): SUM() over decimal(8,2) widens the result; a narrow local
  -- would raise "Data truncated" (1264) inside the trigger on a large total,
  -- turning a valid update into a confusing failure.
  DECLARE v_delivered DECIMAL(20,2);
  DECLARE v_spoiled   DECIMAL(20,2);

  -- Only a reduction can break the invariant; increases and no-op updates are
  -- untouched, so unrelated edits never fail because of pre-existing data.
  IF NEW.`quantity_kg` < OLD.`quantity_kg` THEN

    -- Two scalar subqueries, not two JOINs: joining both child tables would
    -- multiply rows and under-count the protected total.
    SELECT COALESCE(SUM(`quantity_delivered_kg`), 0)
      INTO v_delivered
      FROM `delivery_item`
     WHERE `food_item_id` = OLD.`food_item_id`;

    SELECT COALESCE(SUM(`quantity_spoiled_kg`), 0)
      INTO v_spoiled
      FROM `spoilage_record`
     WHERE `food_item_id` = OLD.`food_item_id`;

    -- COALESCE handles items with no deliveries and no spoilage: 0 + 0, so any
    -- positive new quantity passes.
    IF NEW.`quantity_kg` < v_delivered + v_spoiled THEN
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT =
          'Reduced quantity is below the quantity already delivered plus spoiled.';
    END IF;
  END IF;
END;;

DELIMITER ;

-- ---------------------------------------------------------------------------
-- How this interacts with the existing protections (no duplication, no gap)
-- ---------------------------------------------------------------------------
-- Existing, unchanged:
--   trg_delivery_item_insert / _update
--       guards the numerator: item belongs to the delivery's donation and
--       delivered + spoiled + new <= donated.
--   trg_spoilage_quantity_insert / _update
--       guards the numerator from the spoilage side.
--   chk_donation_quantity, chk_spoilage_quantity, chk_delivery_quantity
--       reject non-positive quantities.
--   FK delivery_item.food_item_id -> donation_item.food_item_id (RESTRICT)
--       prevents deleting an allocated item.
-- New here:
--   the only remaining path — lowering quantity_kg after allocation — is
--   closed. Nothing above is modified, weakened or replaced.
--
-- ---------------------------------------------------------------------------
-- Concurrency: why the trigger alone is not sufficient
-- ---------------------------------------------------------------------------
-- A trigger reads a consistent snapshot; it does not lock the child rows. Two
-- concurrent transactions can each see "delivered = 80" and each pass.
-- Therefore every write path that consumes or changes an item's quantity takes
-- a row lock FIRST, on the same row, in this order:
--
--   BEGIN;
--     SELECT quantity_kg FROM donation_item
--      WHERE food_item_id = :id FOR UPDATE;        -- serialisation point
--     ... compute remaining = quantity_kg - delivered - spoiled ...
--     INSERT INTO delivery_item (...) ;            -- or UPDATE donation_item
--   COMMIT;
--
-- Allocation (delivery_item insert), spoilage recording and quantity edits all
-- acquire that same lock, so they serialise against each other. The trigger
-- remains the last line of defence for any path that forgets to lock — it will
-- reject the impossible row rather than let it through.
--
-- Documented residual risk: a statement that bypasses the lock protocol can
-- still oversubscribe in a narrow window; the audit invariant alloc_le_donated
-- detects the result. This is the same trade-off the original schema made, now
-- narrowed from "any UPDATE" to "only a protocol bypass".
--
-- Not in scope of this migration (flagged, not silently fixed):
--   changing donation_item.donation_id while delivery_item rows exist can
--   create a cross-donation allocation. No trigger prevents it today; the audit
--   invariant delivery_item_same_donation detects it. A follow-up trigger can be
--   added if the product needs item re-parenting at all (recommended: forbid it
--   in the service layer instead).
--
-- ---------------------------------------------------------------------------
-- Validation after applying (read-only, or dev-only for the negative case)
-- ---------------------------------------------------------------------------
-- V005-A  trigger exists on donation_item, BEFORE UPDATE
-- V005-B  increase passes:  UPDATE donation_item SET quantity_kg = quantity_kg + 1 ...
-- V005-C  reduction to exactly delivered+spoiled passes
-- V005-D  reduction below delivered+spoiled raises 1644 (dev DB only)
-- V005-E  item with no delivery_item and no spoilage: reduction to 0.01 passes
--         (positive CHECK still applies)
-- V005-F  item with no children: reduction rejected only by chk_donation_quantity
--         when the new value is <= 0, i.e. 3819 from the CHECK, not 1644
--
-- ---------------------------------------------------------------------------
-- Rollback
-- ---------------------------------------------------------------------------
-- DROP TRIGGER `trg_donation_item_quantity_update`;
-- Complete and safe: no data is created or altered by this object.
