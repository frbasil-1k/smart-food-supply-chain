-- ============================================================================
-- 007_vw_donor_impact.sql   —   donor impact, corrected reporting
-- DRAFT — UNEXECUTED **AND REVIEW-GATED**.
--
-- Do not apply this file until the numbers it returns have been reviewed on a
-- restored copy of the database. It is deliberately last in the sequence and
-- deliberately separate from 001-006.
--
-- `vw_donor_sustainability` IS PRESERVED UNCHANGED. This file only adds a new
-- view alongside it.
--
-- PRECONDITION (require 0 rows):
--   SELECT table_name FROM information_schema.views
--    WHERE table_schema = DATABASE() AND table_name = 'vw_donor_impact';
-- ============================================================================

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_donor_impact` AS
SELECT u.`user_id`                                    AS `donor_id`,
       u.`full_name`                                  AS `donor_name`,
       COALESCE(h.`total_donations`, 0)               AS `total_donations`,
       COALESCE(h.`total_donated_kg`, 0)              AS `total_donated_kg`,
       COALESCE(dv.`delivered_kg`, 0)                 AS `delivered_kg`,
       COALESCE(sp.`spoiled_kg`, 0)                   AS `spoiled_kg`,
       COALESCE(h.`total_donated_kg`, 0)
         - COALESCE(dv.`delivered_kg`, 0)
         - COALESCE(sp.`spoiled_kg`, 0)               AS `undistributed_balance_kg`
  FROM `app_user` u
  LEFT JOIN (SELECT d.`donor_user_id`,
                    COUNT(DISTINCT d.`donation_id`)   AS `total_donations`,
                    SUM(i.`quantity_kg`)              AS `total_donated_kg`
               FROM `donation` d
               LEFT JOIN `donation_item` i ON i.`donation_id` = d.`donation_id`
              WHERE d.`donation_status` <> 'CANCELLED'
              GROUP BY d.`donor_user_id`) h      ON h.`donor_user_id`  = u.`user_id`
  LEFT JOIN (SELECT d.`donor_user_id`,
                    SUM(di.`quantity_delivered_kg`)   AS `delivered_kg`
               FROM `donation` d
               JOIN `delivery` d2      ON d2.`donation_id` = d.`donation_id`
               JOIN `delivery_item` di ON di.`delivery_id` = d2.`delivery_id`
              WHERE d2.`delivery_status` = 'DELIVERED'
                AND d.`donation_status`  <> 'CANCELLED'
              GROUP BY d.`donor_user_id`) dv     ON dv.`donor_user_id` = u.`user_id`
  LEFT JOIN (SELECT d.`donor_user_id`,
                    SUM(s.`quantity_spoiled_kg`)      AS `spoiled_kg`
               FROM `donation` d
               JOIN `donation_item`  i2 ON i2.`donation_id`  = d.`donation_id`
               JOIN `spoilage_record` s ON s.`food_item_id`   = i2.`food_item_id`
              WHERE d.`donation_status` <> 'CANCELLED'
              GROUP BY d.`donor_user_id`) sp     ON sp.`donor_user_id` = u.`user_id`
 WHERE u.`user_role` = 'DONOR';

-- ---------------------------------------------------------------------------
-- Why each piece exists
-- ---------------------------------------------------------------------------
-- CANCELLED excluded from ALL THREE aggregates. A cancelled donation must not
--   appear in donated, delivered or spoiled, otherwise the balance is computed
--   from inconsistent denominators. (Nothing is cancelled in the current data —
--   4 COMPLETED + 1 APPROVED — so this is a correctness guarantee, not a
--   visible change today.)
-- delivered_kg counts only delivery_status = 'DELIVERED'. The existing view
--   counts every allocation, including PLANNED, IN_TRANSIT, FAILED and
--   CANCELLED, which overstates impact.
-- spoiled_kg is its own column. Spoiled food is a loss, never impact; it is
--   reported separately and subtracted only to produce the balance.
-- undistributed_balance_kg = donated - delivered - spoiled. This is an
--   ACCOUNTING BALANCE, not physical stock. The food may be in transit, awaiting
--   inspection, held at a branch without a recorded delivery, or gone without a
--   delivery or spoilage entry. The UI label must be "undistributed balance";
--   "on hand", "remaining stock" and "available" are prohibited labels.
-- Pre-aggregated subqueries (h/dv/sp) keep each metric independent: with plain
--   joins, one donation with 3 items and 2 deliveries would triple the item sum.
--
-- Security: SQL SECURITY DEFINER matches the two existing views, so the app
-- account needs SELECT on the view but not a broader grant. The definer must be
-- an account with SELECT on app_user, donation, donation_item, delivery,
-- delivery_item and spoilage_record.
--
-- ---------------------------------------------------------------------------
-- Review gate (before this is ever applied)
-- ---------------------------------------------------------------------------
-- 1. Run the SELECT form of this query on the restore-verification copy.
-- 2. Confirm, donor by donor, that delivered_kg <= total_donated_kg and that
--    undistributed_balance_kg >= 0. A negative balance means delivered+spoiled
--    exceeds donated, which alloc_le_donated should already prevent; if it
--    appears, investigate the data rather than the view.
-- 3. Compare against vw_donor_sustainability and be able to explain every
--    difference (they should all be un-DELIVERED allocations).
-- 4. Only then apply.
--
-- ---------------------------------------------------------------------------
-- Validation after applying
-- ---------------------------------------------------------------------------
-- V007-A  SELECT COUNT(*) FROM information_schema.views
--          WHERE table_schema = DATABASE() AND table_name = 'vw_donor_impact';  -- 1
-- V007-B  vw_donor_sustainability still present and unchanged               -- 1
-- V007-C  no donor has a negative balance                                   -- 0
-- V007-D  no donor has delivered_kg > total_donated_kg                      -- 0
-- V007-E  every DONOR in app_user appears exactly once                       -- 4
--
-- ---------------------------------------------------------------------------
-- Rollback
-- ---------------------------------------------------------------------------
-- DROP VIEW `vw_donor_impact`;
-- Fully reversible; no data is touched.
