# PHASE 1 — TEST MATRIX

**Preparation only.** None of these has been executed against any database.
Negative probes must run against `smart_food_supply_chain_dev` — never against
the live database. The queries below are the intent; the executable forms live
in the numbered migration files and `validation/VALIDATION_ALL.sql`.

Layer key: **SQL** = direct statements on the dev database, **API** = backend
integration test through the Flask app, **AUD** = `database/audit_db.py`.

---

## 1. USER_CREDENTIAL (F1)

| ID | Layer | Operation | Expected |
|---|---|---|---|
| F1-01 | SQL | `SELECT COUNT(*) FROM user_credential` after migration | 0 |
| F1-02 | SQL | `INSERT` a second credential for the same `user_id` | 1062 duplicate |
| F1-03 | SQL | `INSERT` credential for `user_id = 999999` | 1452 FK |
| F1-04 | SQL | `INSERT` hash `'plaintext123'` | accepted by SQL; **AUD F1-10 must flag it** (format is a service rule) |
| F1-05 | SQL | `UPDATE` set `locked_until = NOW() + 15m`, `failed_attempts = 0` | 3819 CHECK |
| F1-06 | SQL | `DELETE FROM app_user` for a user with a credential (dev) | credential row deleted (CASCADE), no FK error |
| F1-07 | API | login as a user with no credential row | 401, generic "invalid credentials", no user-existence leak |
| F1-08 | API | 5 wrong passwords, then the right one | 401 ×5, then 423/429 "locked"; `failed_attempts = 5`, `locked_until` set |
| F1-09 | API | correct password during lock | rejected; lock not extended by a correct attempt |
| F1-10 | API | successful login after lock expiry | 200; `failed_attempts = 0`, `locked_until = NULL`, `last_login_at` set |
| F1-11 | API | `GET /auth/me`, `GET /users/{id}` | no `password_hash`, no `reset_token_hash`, ever |
| F1-12 | API | activation flow: invite → use token → reuse the same token | 200, then 410/401 (single use) |
| F1-13 | API | activation with an expired token | 410/401, no credential written |
| F1-14 | AUD | `cred_users_missing` / `cred_non_scrypt_hash` / `cred_locked_out` | 15 / 0 / 0 after migration |

## 2. DONATION_STATUS_HISTORY (F2)

| ID | Layer | Operation | Expected |
|---|---|---|---|
| F2-01 | SQL | count after migration | exactly 5 |
| F2-02 | SQL | reconstructed rows with `changed_at` set | 3819 CHECK |
| F2-03 | SQL | reconstructed row with `changed_by_user_id` set | 3819 CHECK |
| F2-04 | SQL | genuine row (`is_reconstructed = 0`) with `changed_at NULL` | 3819 CHECK |
| F2-05 | SQL | `from_status = to_status` | 3819 CHECK |
| F2-06 | SQL | two reconstructed rows for one donation | accepted by SQL if inserted directly; `V002` detects it — the backfill's `NOT EXISTS` prevents it in practice |
| F2-07 | SQL | `to_status` value outside the enum | 1265 truncation warning in strict mode → error |
| F2-08 | API | genuine transition PENDING → SCHEDULED | one history row: `from PENDING`, `to SCHEDULED`, actor = current user, `changed_at` NOT NULL, `is_reconstructed = 0` |
| F2-09 | API | transition attempt PENDING → COMPLETED | 409 invalid transition, **no** history row written |
| F2-10 | API | `APPROVED` while latest inspection is FAILED | 409, no history row |
| F2-11 | API | transition where the history INSERT fails (simulated) | the donation status is **not** changed (single transaction) |
| F2-12 | API | `GET /donations/{id}` timeline | reconstructed node rendered hollow, no time, "earlier transitions were not recorded" |
| F2-13 | AUD | `hist_missing_donation`, `hist_invented_timestamp`, `hist_missing_timestamp`, `hist_duplicate_snapshot` | 0 / 0 / 0 / 0 |

## 3. DONATION pickup (F3)

| ID | Layer | Operation | Expected |
|---|---|---|---|
| F3-01 | SQL | existing rows after migration | `pickup_address/pincode/contact` all NULL (5/5/5) |
| F3-02 | API | create donation without `pickup_address` | 422 with a field-level message |
| F3-03 | API | create with address `"   "` | 422 (whitespace-only is empty) |
| F3-04 | API | create with a valid address + `"560 001"` + `"98765 43210"` | 201; stored normalised `560001` / `+919876543210` |
| F3-05 | API | pincode `"056001"` | 422 (leading zero) |
| F3-06 | API | pincode `"56001"` / `"5600011"` | 422 (length) |
| F3-07 | API | pincode `"56A001"` | 422 (non-digit) |
| F3-08 | API | contact `"12345"` / `"08012345678"` | 422 |
| F3-09 | API | donor edits a legacy donation to add pickup details | 200; NULL replaced with real data, no fabricated history |
| F3-10 | API | driver task card for a legacy donation | shows "Pickup address not recorded" and a contact-manager action, not a blank |
| F3-11 | AUD | `donation_missing_pickup_address` | 5 after migration, unchanged until the donor edits |

## 4. DELIVERY driver attribution (F4)

| ID | Layer | Operation | Expected |
|---|---|---|---|
| F4-01 | SQL | existing rows | `driver_user_id` NULL ×5, `scheduled_for` NULL ×5 |
| F4-02 | SQL | set `driver_user_id` to an NGO_MANAGER | 1644 "Delivery driver must have DRIVER role." |
| F4-03 | SQL | set `driver_user_id` to a DONOR | 1644 |
| F4-04 | SQL | set `driver_user_id` to an unknown id | 1452 FK |
| F4-05 | SQL | set `driver_user_id` to a DRIVER | success |
| F4-06 | SQL | two deliveries for the same `(donation_id, recipient_branch_id)` | both insert (no unique key) |
| F4-07 | SQL | insert a delivery with `driver_user_id` set to a SUSPENDED driver | accepted (role only) — **the service must reject it**; documented trade-off |
| F4-08 | API | assign a SUSPENDED/INACTIVE driver | 422 ineligible account |
| F4-09 | API | assign a DRIVER not on the delivery's route | 422 |
| F4-10 | API | move to `IN_TRANSIT` with no driver | 422; or the same UPDATE sets the acting driver |
| F4-11 | API | change `driver_user_id` after `DELIVERED` | 409 for a driver; allowed only as an explicit manager correction (per open question 6) |
| F4-12 | API | driver performance report | confirmed kg counts only attributed DELIVERED rows; unattributed delivered kg reported separately (expect all delivered kg unconfirmed today) |
| F4-13 | AUD | `driver_legacy_null`, `driver_role_invalid_active`, `driver_confirmed_delivered_kg`, `driver_unconfirmed_delivered_kg` | 5, 0, 0, and the full delivered total |
| F4-14 | AUD | `delivery_driver_history` | changes from NOT AVAILABLE to an observation, exit code unaffected |

## 5. DONATION_ITEM quantity guard (F5)

Seed (dev only, inside a rolled-back transaction where possible):
item `A` donated 100 kg, delivered 60 kg, spoiled 10 kg; item `B` donated 50 kg,
no children; item `C` donated 20 kg, delivered 20 kg exactly.

| ID | Layer | Operation | Expected |
|---|---|---|---|
| F5-01 | SQL | `A.quantity_kg = 120` (increase) | success |
| F5-02 | SQL | `A.quantity_kg = 70` (above 70 committed) | success |
| F5-03 | SQL | `A.quantity_kg = 70.00` (exactly the committed total) | success (boundary is inclusive) |
| F5-04 | SQL | `A.quantity_kg = 69.99` | 1644 |
| F5-05 | SQL | `A` unrelated column update, quantity untouched | success (guard only fires on reduction) |
| F5-06 | SQL | `B.quantity_kg = 10` (no children) | success |
| F5-07 | SQL | `B.quantity_kg = 0` | 3819 from `chk_donation_quantity`, not 1644 |
| F5-08 | SQL | `C.quantity_kg = 19` (below the 20 allocated) | 1644 |
| F5-09 | SQL | item with 3 deliveries and 2 spoilage rows, no fan-out error | the sum must equal the true total, not a multiplied one |
| F5-10 | SQL | `INSERT` a new `delivery_item` pushing allocation past donated | existing `trg_delivery_item_*` rejects it (unchanged) |
| F5-11 | API | `PATCH /donation-items/{id}` below the committed amount | 409 with the committed total in the message |
| F5-12 | API | concurrent allocate + reduce (two sessions) | the `SELECT … FOR UPDATE` serialises them; one gets 409/1644, invariant holds |
| F5-13 | AUD | `alloc_le_donated` | still passes after the concurrency test |

## 6. Temperature plausibility (F8)

| ID | Layer | Operation | Expected |
|---|---|---|---|
| F8-01 | SQL | `temperature_c = NULL` | accepted |
| F8-02 | SQL | `-50.00` and `150.00` | accepted (inclusive bounds) |
| F8-03 | SQL | `-50.01` and `150.01` | 3819 |
| F8-04 | SQL | `3.40` (ordinary fridge reading) | accepted — plausibility is not safety |
| F8-05 | API | submit a temperature of `340` with `safety_status = PASSED` | 422 field error naming plausibility, not safety |
| F8-06 | API | submit `NULL` temperature with `safety_status = PASSED` | accepted; the UI must not invent a reading |
| F8-07 | API | `safety_status = FAILED` at a perfectly plausible temperature | accepted — the two judgements are independent |
| F8-08 | AUD | `temperature_out_of_range` | 0 |

## 7. Cross-cutting

| ID | Layer | Operation | Expected |
|---|---|---|---|
| X-01 | SQL | preflight P8/P9 vs V000 | identical counts (104) and identical content fingerprint |
| X-02 | SQL | `collation` / `charset` of every new column | `utf8mb4_0900_ai_ci`, matching the existing tables |
| X-03 | AUD | full audit after all migrations, with the approved post-migration baseline | exit 0, all invariants pass, new objects explained once each |
| X-04 | AUD | `--self-test` | 39 assertions pass (unchanged by this phase) |
| X-05 | SQL | re-run any applied migration file | precondition query returns non-zero → runner refuses, no partial apply |
| X-06 | SQL | rollback script on the dev database, then audit with the **pre**-migration baseline | exit 0; schema back to the 15-table/2-view/16-trigger state |
| X-07 | API | full donor → manager → driver → inspector flow on dev | end-to-end status, allocation, delivery, inspection and report numbers agree |

---

## 8. What these tests do **not** prove

- Passing SQL tests does not prove the *service* enforces actor, scope and
  transition rules — the API rows above cover that and must be implemented in
  Phase 3 before they can run.
- A concurrency test that passes once is not a proof. F5-12 must be repeated
  (at least 20 iterations) before the lock protocol is trusted.
- Restore verification proves the dump restores into a scratch schema; it does
  not prove the production host has space or time for it. Rehearse on the same
  machine, not a laptop.
