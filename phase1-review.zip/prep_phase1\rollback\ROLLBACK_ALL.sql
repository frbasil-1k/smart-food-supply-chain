-- ============================================================================
-- ROLLBACK_ALL.sql   —   reverse of 001..007
-- DRAFT — UNEXECUTED.
--
-- READ ALL OF THIS BEFORE RUNNING ANY LINE.
--
-- MySQL performs an implicit COMMIT before and after each DDL statement. DDL is
-- therefore NOT transactional: there is no "ROLLBACK the migration". This file
-- is a sequence of compensating DDL statements that you run deliberately, one
-- numbered step at a time, after deciding that reverting is the right call.
--
-- Order matters: children before parents, objects before columns.
--   007 -> 006 -> 005 -> 004 -> 003 -> 002 -> 001
--
-- Back up BEFORE rolling back too. A rollback after go-live destroys data that
-- the forward migration created:
--   001  all password hashes (every user must be re-invited)
--   002  all genuine status transitions recorded since the migration
--   003  every pickup address/pincode/contact entered since the migration
--   004  every recorded driver and every scheduled time
--   006  nothing (constraint only) - but it re-exposes the plausibility gap
--   005  nothing (trigger only)
--   007  nothing (view only)
--
-- For 002, 003 and 004, a FORWARD FIX is almost always preferable: the columns
-- and rows are additive, so leaving them in place costs nothing while a drop
-- loses real operational data.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- STEP 1 (007) — donor-impact view
-- Reversible, no data. Safe.
-- ---------------------------------------------------------------------------
DROP VIEW `vw_donor_impact`;

-- ---------------------------------------------------------------------------
-- STEP 2 (006) — temperature plausibility CHECK
-- Reversible, no data. After this, implausible readings can be stored again.
-- ---------------------------------------------------------------------------
ALTER TABLE `inspection_log`
  DROP CHECK `chk_temperature_range`;

-- ---------------------------------------------------------------------------
-- STEP 3 (005) — donation-item reduction guard
-- Reversible, no data. After this, quantity_kg can be reduced below the
-- delivered + spoiled total again.
-- ---------------------------------------------------------------------------
DROP TRIGGER `trg_donation_item_quantity_update`;

-- ---------------------------------------------------------------------------
-- STEP 4 (004) — delivery driver attribution
-- DESTRUCTIVE once attribution/schedules exist.
-- The triggers go first so no write is validated against a column that is
-- about to disappear.
-- ---------------------------------------------------------------------------
DROP TRIGGER `trg_delivery_driver_update`;
DROP TRIGGER `trg_delivery_driver_insert`;

ALTER TABLE `delivery`
  DROP FOREIGN KEY `fk_delivery_driver`,
  DROP KEY `idx_delivery_scheduled`,
  DROP KEY `idx_delivery_driver_status`,
  DROP COLUMN `scheduled_for`,
  DROP COLUMN `driver_user_id`;

-- If you only want to undo the triggers and keep the columns, stop after the
-- two DROP TRIGGER statements — that alone removes the role gate.

-- ---------------------------------------------------------------------------
-- STEP 5 (003) — donation pickup columns
-- DESTRUCTIVE once donors have entered pickup details.
-- ---------------------------------------------------------------------------
ALTER TABLE `donation`
  DROP COLUMN `pickup_contact`,
  DROP COLUMN `pickup_pincode`,
  DROP COLUMN `pickup_address`;

-- ---------------------------------------------------------------------------
-- STEP 6 (002) — donation status history
-- DESTRUCTIVE once the application has written any transition. The reconstructed
-- snapshot rows can be recreated at any time; genuine history cannot.
-- ---------------------------------------------------------------------------
-- Export first if there is any doubt:
--   SELECT * FROM donation_status_history
--    INTO OUTFILE 'C:/backup/donation_status_history_YYYYMMDD.csv'
--    FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n';
DROP TABLE `donation_status_history`;

-- ---------------------------------------------------------------------------
-- STEP 7 (001) — credentials
-- DESTRUCTIVE: every hash is lost. All users must be re-invited afterwards.
-- app_user is untouched throughout.
-- ---------------------------------------------------------------------------
-- Export first if the hashes matter (they cannot be re-derived):
--   SELECT user_id, password_hash, must_change_password, created_at
--     FROM user_credential
--    INTO OUTFILE 'C:/backup/user_credential_YYYYMMDD.csv'
--    FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n';
DROP TABLE `user_credential`;

-- ---------------------------------------------------------------------------
-- POST-ROLLBACK VERIFICATION
-- ---------------------------------------------------------------------------
-- 1. Re-run 000_preflight.sql: P4 must show 0 for all three objects, P5 must
--    return 0 rows, P6 must return 0 rows, and P8 must still total 104 with the
--    same per-table counts.
-- 2. Run `python database/audit_db.py` and require exit 0 with the ORIGINAL
--    baseline (database/schema.sql) — after a complete rollback the live schema
--    is byte-compatible with the pre-migration export again, so B.3 must pass
--    with the pre-migration baseline file.
-- 3. If the audit reports new objects, the rollback was incomplete: do not
--    re-run the migration until the leftovers are identified.
--
-- ---------------------------------------------------------------------------
-- WHEN NOT TO ROLL BACK
-- ---------------------------------------------------------------------------
-- Roll back a STRUCTURAL mistake (bad type, wrong constraint, trigger that
-- blocks legitimate work) before any data depends on it.
-- Do NOT roll back to "clean up" after the application has been running: the
-- additive objects are inert if unused, while the drop is irreversible for the
-- data collected in the meantime. Use a forward-fix migration in that case.
