-- ============================================================================
-- 001_user_credential.sql   —   F1: authentication table
-- DRAFT — UNEXECUTED. Do not run outside the approved migration batch.
--
-- Creates exactly one new table. APP_USER is not modified in any way.
-- Nothing is inserted: existing users get NO credential row (see below).
--
-- PRECONDITION (run and require 0 rows):
--   SELECT table_name FROM information_schema.tables
--    WHERE table_schema = DATABASE() AND table_name = 'user_credential';
--
-- See 000_preflight.sql P4/P5/P8 for the batch-level checks.
-- ============================================================================

CREATE TABLE `user_credential` (
  `user_id`              INT              NOT NULL
                         COMMENT 'One credential row per APP_USER; PK enforces uniqueness',
  `password_hash`        VARCHAR(255)     NOT NULL
                         COMMENT 'Werkzeug scrypt hash, e.g. scrypt:32768:8:1$salt$digest',
  `must_change_password` TINYINT(1)       NOT NULL DEFAULT 1
                         COMMENT '1 until the user sets their own password',
  `failed_attempts`      TINYINT UNSIGNED NOT NULL DEFAULT 0
                         COMMENT 'Consecutive failures; reset to 0 on success',
  `locked_until`         DATETIME         NULL DEFAULT NULL
                         COMMENT 'Temporary lock expiry; NULL = not locked',
  `last_login_at`        DATETIME         NULL DEFAULT NULL,
  `password_changed_at`  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reset_token_hash`     CHAR(64)         NULL DEFAULT NULL
                         COMMENT 'SHA-256 hex of a single-use activation/reset token',
  `reset_expires_at`     DATETIME         NULL DEFAULT NULL,
  `created_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_cred_reset_token` (`reset_token_hash`),
  CONSTRAINT `fk_credential_user` FOREIGN KEY (`user_id`)
    REFERENCES `app_user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_cred_lock_consistency`
    CHECK (`locked_until` IS NULL OR `failed_attempts` > 0)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci
  COMMENT='Authentication material, deliberately separate from APP_USER profile data';

-- ---------------------------------------------------------------------------
-- Design notes
-- ---------------------------------------------------------------------------
-- PK user_id          Enforces "one credential record per user" structurally;
--                     a second INSERT for the same user fails with 1062.
-- FK ON DELETE CASCADE A deleted user's credential must not survive. The app
--                     does not delete users (it sets account_status), so this
--                     is a safety net, not a workflow.
-- uq_cred_reset_token Tokens are looked up on activation/reset, so the lookup
--                     needs an index; UNIQUE also prevents collisions. MySQL
--                     permits many NULLs in a UNIQUE index, so ordinary rows
--                     are unaffected.
-- chk_cred_lock_*     One-way coherence: a lock must have been earned by a
--                     failure. Unlocking by setting locked_until = NULL while
--                     leaving the counter is still allowed (admin unlock), so
--                     the CHECK cannot trap an account.
-- No CHECK on password_hash format
--                     Deliberate: pinning 'scrypt:%' in the schema would couple
--                     the database to Werkzeug's current default and break a
--                     future migration to argon2. Format is enforced in one
--                     service function and verified by the audit invariant
--                     cred_non_scrypt_hash.
--
-- ---------------------------------------------------------------------------
-- Existing users: NOTHING IS INSERTED HERE
-- ---------------------------------------------------------------------------
-- The 15 existing APP_USER rows receive no credential. Their logins fail with
-- the same generic message as a wrong password (no user enumeration) until a
-- manager issues an activation token:
--   1. manager POST /api/v1/users/{id}/credential-invite
--   2. server writes reset_token_hash = sha256(token), reset_expires_at = now+24h
--      and returns the raw token once, out of band
--   3. user POST /api/v1/auth/activate {token, new_password}
--   4. server verifies hash, expiry and single use; writes password_hash with
--      Werkzeug scrypt, must_change_password = 0, clears the token fields
-- No password or hash is invented for anyone, and no shared default exists.
--
-- Lockout policy (application layer, values to be confirmed by the product owner)
--   - 5 consecutive failures -> locked_until = now + 15 minutes
--   - lock duration doubles up to 60 minutes on repeated lockouts
--   - success resets failed_attempts = 0 AND locked_until = NULL (required by
--     chk_cred_lock_consistency)
--   - per-IP throttling runs in addition to per-account lockout, so an attacker
--     cannot cheaply lock every account from one address
--   - the audit observation cred_locked_out reports currently locked accounts,
--     which is how a mass-lockout attempt becomes visible
--
-- ---------------------------------------------------------------------------
-- Validation after applying (read-only)
-- ---------------------------------------------------------------------------
-- V001-A  table exists with 11 columns and 1 unique index
-- V001-B  SELECT COUNT(*) FROM user_credential;                    -- expect 0
-- V001-C  SELECT COUNT(*) FROM app_user u LEFT JOIN user_credential c
--          USING (user_id) WHERE c.user_id IS NULL;                 -- expect 15
-- V001-D  the FK rejects an unknown user:
--         INSERT INTO user_credential (user_id, password_hash)
--         VALUES (999999, REPEAT('x',60));                         -- expect 1452
--
-- ---------------------------------------------------------------------------
-- Rollback
-- ---------------------------------------------------------------------------
-- DROP TABLE `user_credential`;
-- Safe with respect to other tables (nothing references it). It destroys the
-- hashes: after rollback every user must be re-invited. If users had already
-- set passwords, treat rollback as data loss and prefer a forward fix.
