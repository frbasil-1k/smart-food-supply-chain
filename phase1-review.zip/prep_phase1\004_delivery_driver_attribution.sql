-- ============================================================================
-- 004_delivery_driver_attribution.sql   —   F4: who actually drove
-- DRAFT — UNEXECUTED. Do not run outside the approved migration batch.
--
-- 004a: two nullable columns, one composite index, one planned-time index, one FK.
-- 004b: two role-gate triggers mirroring the existing trg_route_driver_* pair.
--
-- NO BACKFILL. Every existing DELIVERY row keeps driver_user_id = NULL and
-- scheduled_for = NULL. The route's designated driver is that route's CURRENT
-- designation; writing it into historical deliveries would fabricate the past.
--
-- PRECONDITION (require 0 rows):
--   SELECT column_name FROM information_schema.columns
--    WHERE table_schema = DATABASE() AND table_name = 'delivery'
--      AND column_name IN ('driver_user_id','scheduled_for');
--   SELECT trigger_name FROM information_schema.triggers
--    WHERE trigger_schema = DATABASE()
--      AND trigger_name IN ('trg_delivery_driver_insert','trg_delivery_driver_update');
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 004a — structure
-- ---------------------------------------------------------------------------
ALTER TABLE `delivery`
  ADD COLUMN `driver_user_id` INT NULL DEFAULT NULL
    COMMENT 'ACTUAL driver; NULL = not recorded (all pre-F4 rows stay NULL)'
    AFTER `route_id`,
  ADD COLUMN `scheduled_for` DATETIME NULL DEFAULT NULL
    COMMENT 'Planned delivery window; NULL = not scheduled/not recorded'
    AFTER `delivered_at`,
  ADD KEY `idx_delivery_driver_status` (`driver_user_id`, `delivery_status`),
  ADD KEY `idx_delivery_scheduled` (`scheduled_for`),
  ADD CONSTRAINT `fk_delivery_driver` FOREIGN KEY (`driver_user_id`)
    REFERENCES `app_user` (`user_id`);

-- Index rationale
--   idx_delivery_driver_status  Every driver screen filters
--                               "my deliveries, by status", and the driver
--                               performance report groups by driver. The index
--                               is composite because driver alone is not
--                               selective enough at tens of thousands of rows,
--                               and its leading column also satisfies the FK's
--                               index requirement.
--   idx_delivery_scheduled      The manager's "planned deliveries this week"
--                               view filters a date range.
--   Deliberately absent: UNIQUE(donation_id, recipient_branch_id).
--                               Splitting one donation across the same branch
--                               twice is an approved workflow; the allocation
--                               workspace prevents accidental duplicates in the
--                               service layer instead of in a unique key.
--
-- No CHECK on driver_user_id: NULL is legal and meaningful (legacy). Role
-- eligibility is enforced by 004b and by the service layer.
--
-- ---------------------------------------------------------------------------
-- 004b — role gates (mirror trg_route_driver_insert / _update)
-- ---------------------------------------------------------------------------
-- The existing triggers allow multiple triggers per event; MySQL fires them in
-- creation order. Order is irrelevant here because these conditions are
-- independent of trg_delivery_inspection_*: role validity vs inspection gate.
--
-- Note: any UPDATE that touches an existing DELIVERED/IN_TRANSIT row re-runs
-- trg_delivery_inspection_update (existing behaviour, unchanged). Writing
-- driver_user_id onto a delivered row therefore re-validates that the latest
-- inspection passed — which the verified baseline already satisfies for all 5
-- deliveries.
DELIMITER ;;

CREATE TRIGGER `trg_delivery_driver_insert`
BEFORE INSERT ON `delivery`
FOR EACH ROW
BEGIN
  IF NEW.`driver_user_id` IS NOT NULL
     AND NOT EXISTS (
           SELECT 1 FROM `app_user`
            WHERE `user_id` = NEW.`driver_user_id`
              AND `user_role` = 'DRIVER') THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Delivery driver must have DRIVER role.';
  END IF;
END;;

CREATE TRIGGER `trg_delivery_driver_update`
BEFORE UPDATE ON `delivery`
FOR EACH ROW
BEGIN
  IF NEW.`driver_user_id` IS NOT NULL
     AND NOT EXISTS (
           SELECT 1 FROM `app_user`
            WHERE `user_id` = NEW.`driver_user_id`
              AND `user_role` = 'DRIVER') THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Delivery driver must have DRIVER role.';
  END IF;
END;;

DELIMITER ;

-- Why the trigger checks the role but not account_status:
--   The database must never accept a delivery attributed to a manager or a
--   donor — that is a role-integrity invariant, exactly like the existing route
--   trigger. Account status is different: it changes over time (reinstatement,
--   suspension) and enforcing ACTIVE here would mean a suspended driver's
--   existing rows become un-updatable and could not be repaired without first
--   re-activating them. ACTIVE eligibility therefore belongs in the assignment
--   service: POST /deliveries/{id}/driver rejects a non-ACTIVE account with 422,
--   while the DB guarantees only the role.
--
-- ---------------------------------------------------------------------------
-- Service-layer rules for driver assignment (future implementation)
-- ---------------------------------------------------------------------------
--  1. target user must exist, be ACTIVE, and hold DRIVER
--  2. target must belong to the delivery's route, as designated driver OR via
--     a ROUTE_ASSIGNMENT row for that route (route_assignment permits DRIVER
--     and SAFETY_INSPECTOR, so "assigned to the route" is not the same as
--     "allowed to drive"; role is still required)
--  3. driver_user_id may not be changed once delivery_status = 'DELIVERED'
--     (attribution is a fact at that point); correcting it is an explicit
--     manager-level operation with a reason, recorded in history
--  4. when delivery_status moves to IN_TRANSIT and driver_user_id is NULL, the
--     service must set the acting driver in the same UPDATE — a delivery cannot
--     leave without an attributed driver
--  5. scheduled_for, when supplied, must be >= donation.pickup_datetime and a
--     future timestamp on creation; it is never derived automatically
--
-- ---------------------------------------------------------------------------
-- Legacy and reporting behaviour
-- ---------------------------------------------------------------------------
-- All 5 existing deliveries keep NULL in both columns. The UI renders
-- "Driver not recorded" / "Not scheduled". Confirmed per-driver totals count
-- only rows with a recorded driver; the unconfirmed remainder is reported as a
-- separate figure, never attributed through the route. The audit's
-- driver_confirmed_delivered_kg / driver_unconfirmed_delivered_kg pair already
-- implements that split.
--
-- ---------------------------------------------------------------------------
-- Validation after applying (read-only)
-- ---------------------------------------------------------------------------
-- V004-A  two columns exist, both nullable, no default
-- V004-B  SELECT COUNT(*) FROM delivery WHERE driver_user_id IS NULL;   -- expect 5
-- V004-C  SELECT COUNT(*) FROM delivery WHERE scheduled_for  IS NULL;   -- expect 5
-- V004-D  two triggers exist on `delivery`, timing BEFORE, events INSERT/UPDATE
-- V004-E  FK fk_delivery_driver present, referencing app_user(user_id)
-- V004-F  role gate (dev DB only):
--         UPDATE delivery SET driver_user_id = (a manager's id) WHERE delivery_id = 1;
--         -- expect 1644 'Delivery driver must have DRIVER role.'
-- V004-G  multiple deliveries per (donation, branch) still allowed:
--         INSERT ... two PLANNED rows for the same pair;              -- expect success
--
-- ---------------------------------------------------------------------------
-- Rollback
-- ---------------------------------------------------------------------------
-- DROP TRIGGER `trg_delivery_driver_update`;
-- DROP TRIGGER `trg_delivery_driver_insert`;
-- ALTER TABLE `delivery`
--   DROP FOREIGN KEY `fk_delivery_driver`,
--   DROP KEY `idx_delivery_scheduled`,
--   DROP KEY `idx_delivery_driver_status`,
--   DROP COLUMN `scheduled_for`,
--   DROP COLUMN `driver_user_id`;
-- Loses any attribution and schedule entered after go-live.
