-- ============================================================================
-- 000_preflight.sql  —  READ-ONLY PRE-FLIGHT
-- Phase 1 preparation draft. Safe to run repeatedly: every statement is a
-- SELECT against information_schema or a COUNT(*) over the existing tables.
-- No DDL, no DML, no locks beyond normal reads.
--
-- Run this IMMEDIATELY BEFORE the migration batch and save the output next to
-- the backup file. Compare it with the same output captured AFTER the
-- migrations: only the intended differences may appear.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- P1. Server and session environment
-- ---------------------------------------------------------------------------
SELECT VERSION()                                   AS server_version,
       @@sql_mode                                  AS sql_mode,
       @@default_storage_engine                    AS default_engine,
       @@character_set_server                      AS charset,
       @@collation_server                          AS collation,
       @@lower_case_table_names                    AS lower_case_table_names;

-- Expect: 8.0.46, InnoDB, utf8mb4, utf8mb4_0900_ai_ci.
-- STRICT_TRANS_TABLES must be present: the CHECK/ENUM protections rely on it.

-- ---------------------------------------------------------------------------
-- P2. Database identity (guards against running against the wrong schema)
-- ---------------------------------------------------------------------------
SELECT DATABASE() AS current_database;

-- ---------------------------------------------------------------------------
-- P3. Nothing else is mid-write (a concurrent DDL/DML can block ALTER TABLE)
-- ---------------------------------------------------------------------------
SELECT COUNT(*) AS open_innodb_transactions FROM information_schema.innodb_trx;

-- Expect 0. If not 0, wait for the sessions to finish before starting.

-- ---------------------------------------------------------------------------
-- P4. Migration idempotence guard: none of the new objects may already exist
-- ---------------------------------------------------------------------------
SELECT 'user_credential'         AS object_name,
       COUNT(*)                  AS existing
  FROM information_schema.tables
 WHERE table_schema = DATABASE() AND table_name = 'user_credential'
UNION ALL
SELECT 'donation_status_history', COUNT(*)
  FROM information_schema.tables
 WHERE table_schema = DATABASE() AND table_name = 'donation_status_history'
UNION ALL
SELECT 'vw_donor_impact',         COUNT(*)
  FROM information_schema.views
 WHERE table_schema = DATABASE() AND table_name = 'vw_donor_impact';

-- PRECONDITION for 001/002/007: every row must report 0.
-- A non-zero value means the migration was already applied (or partly applied)
-- and must be investigated before anything else is run.

-- ---------------------------------------------------------------------------
-- P5. New columns must not exist yet
-- ---------------------------------------------------------------------------
SELECT table_name, column_name
  FROM information_schema.columns
 WHERE table_schema = DATABASE()
   AND (   (table_name = 'donation' AND column_name IN
            ('pickup_address','pickup_pincode','pickup_contact'))
        OR (table_name = 'delivery'  AND column_name IN
            ('driver_user_id','scheduled_for')))
 ORDER BY table_name, column_name;

-- PRECONDITION for 003/004: zero rows returned.

-- ---------------------------------------------------------------------------
-- P6. Trigger and CHECK name collisions
-- ---------------------------------------------------------------------------
SELECT trigger_name, event_object_table, action_timing, event_manipulation
  FROM information_schema.triggers
 WHERE trigger_schema = DATABASE()
   AND trigger_name IN ('trg_delivery_driver_insert',
                        'trg_delivery_driver_update',
                        'trg_donation_item_quantity_update');

-- PRECONDITION for 004/005: zero rows returned.

SELECT constraint_name, table_name
  FROM information_schema.table_constraints
 WHERE table_schema = DATABASE()
   AND constraint_name = 'chk_temperature_range';

-- PRECONDITION for 006: zero rows returned.

-- ---------------------------------------------------------------------------
-- P7. Existing CHECK constraints on donation_item (F5 must not duplicate them)
-- ---------------------------------------------------------------------------
SELECT tc.table_name, tc.constraint_name, cc.check_clause
  FROM information_schema.table_constraints tc
  JOIN information_schema.check_constraints cc
    ON cc.constraint_schema = tc.constraint_schema
   AND cc.constraint_name   = tc.constraint_name
 WHERE tc.table_schema = DATABASE()
   AND tc.constraint_type = 'CHECK'
 ORDER BY tc.table_name, tc.constraint_name;

-- Expect 6 rows (chk_delivery_quantity, chk_donation_quantity, chk_food_dates,
-- chk_review_rating, chk_route_hours, chk_spoilage_quantity) all ENFORCED.

-- ---------------------------------------------------------------------------
-- P8. Row-count fingerprint — the data-preservation baseline
-- ---------------------------------------------------------------------------
SELECT 'organization'          AS table_name, COUNT(*) AS rows_now FROM organization
UNION ALL SELECT 'branch',              COUNT(*) FROM branch
UNION ALL SELECT 'app_user',            COUNT(*) FROM app_user
UNION ALL SELECT 'route',               COUNT(*) FROM route
UNION ALL SELECT 'coverage_area',       COUNT(*) FROM coverage_area
UNION ALL SELECT 'route_assignment',    COUNT(*) FROM route_assignment
UNION ALL SELECT 'donation',            COUNT(*) FROM donation
UNION ALL SELECT 'food_category',       COUNT(*) FROM food_category
UNION ALL SELECT 'donation_item',       COUNT(*) FROM donation_item
UNION ALL SELECT 'inspection_log',      COUNT(*) FROM inspection_log
UNION ALL SELECT 'dependent',           COUNT(*) FROM dependent
UNION ALL SELECT 'delivery',            COUNT(*) FROM delivery
UNION ALL SELECT 'delivery_item',       COUNT(*) FROM delivery_item
UNION ALL SELECT 'spoilage_record',     COUNT(*) FROM spoilage_record
UNION ALL SELECT 'delivery_review',     COUNT(*) FROM delivery_review;

-- Verified baseline (audit report, live run): every count below must match.
--   organization 3 | branch 5 | app_user 15 | route 5 | coverage_area 5
--   route_assignment 8 | donation 5 | food_category 8 | donation_item 13
--   inspection_log 5 | dependent 6 | delivery 5 | delivery_item 15
--   spoilage_record 1 | delivery_review 5   → TOTAL 104

-- ---------------------------------------------------------------------------
-- P9. Content fingerprint of the rows that migrations touch
--      (a slow-changing aggregate, not a row count: it proves data unchanged)
-- ---------------------------------------------------------------------------
SELECT COUNT(*)                                        AS donations,
       COALESCE(SUM(donation_id), 0)                   AS sum_ids,
       COALESCE(SUM(TIMESTAMPDIFF(SECOND, '2000-01-01',
                pickup_datetime)), 0)                  AS sum_pickup_seconds
  FROM donation;

SELECT COUNT(*)                                        AS delivery_rows,
       COALESCE(SUM(delivery_id), 0)                   AS sum_ids,
       SUM(delivery_status = 'DELIVERED')              AS delivered_rows
  FROM delivery;

SELECT COUNT(*)                                        AS items,
       COALESCE(SUM(quantity_kg), 0)                   AS total_kg,
       COALESCE(SUM(ROUND(quantity_kg * 100)), 0)      AS total_centikg
  FROM donation_item;

SELECT COUNT(*)                                        AS inspections,
       COALESCE(SUM(temperature_c), 0)                  AS sum_temperature,
       SUM(temperature_c IS NULL)                       AS null_temperatures
  FROM inspection_log;

-- ---------------------------------------------------------------------------
-- P10. F8 pre-check — the CHECK validates EXISTING rows when it is added
-- ---------------------------------------------------------------------------
SELECT COUNT(*) AS readings_outside_plausibility_band
  FROM inspection_log
 WHERE temperature_c IS NOT NULL
   AND (temperature_c < -50 OR temperature_c > 150);

-- MUST be 0 before 006 is applied. A non-zero value means the migration will
-- abort (SQLSTATE 3819). Fix or explicitly review those readings; do NOT widen
-- the band to make the migration pass.

-- ---------------------------------------------------------------------------
-- P11. F2 pre-check — donations that will receive a reconstructed snapshot
-- ---------------------------------------------------------------------------
SELECT donation_status, COUNT(*) AS donations
  FROM donation
 GROUP BY donation_status
 ORDER BY donation_status;

-- Expected on the verified baseline: COMPLETED 4, APPROVED 1 (5 snapshots).

-- ---------------------------------------------------------------------------
-- P12. F4 / F3 pre-checks — what legacy NULL will cover
-- ---------------------------------------------------------------------------
-- These two count the rows that will carry NULL after 003/004. They are the
-- exact numbers the post-migration validation must see again.
SELECT COUNT(*) AS deliveries_that_will_have_no_driver,
       SUM(delivery_status = 'DELIVERED') AS delivered_without_driver
  FROM delivery;

SELECT COUNT(*) AS donations_that_will_have_no_pickup_address
  FROM donation;
