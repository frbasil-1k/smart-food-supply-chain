# PHASE 1 — MIGRATION PREPARATION (UNEXECUTED DRAFTS)

> **STATUS: DRAFT ONLY. NOTHING IN THIS DIRECTORY HAS BEEN RUN.**
> No table was created or altered, no trigger or view was added, no row was
> written, and `smart_food_supply_chain_dev` was not created.
>
> These files are **not** in an execution path. There is no runner in the
> repository, no migration directory is wired to anything, and the SQL here is
> deliberately isolated from `database/schema.sql` and `database/audit_db.py`.

Project: **Smart Food Supply Chain & Surplus Redistribution System**
Target: MySQL Server 8.0.46, InnoDB, utf8mb4 / utf8mb4_0900_ai_ci
Primary database: `smart_food_supply_chain` (104 rows, must be preserved)

---

## 1. Read this before anything else

1. `database/schema.sql` is a **reference export containing `DROP TABLE` statements**.
   It must **never** be imported into the live database. It stays frozen as the
   pre-migration baseline that `database/audit_db.py` compares against.
2. These drafts are applied **only** through an approved runner, **only** after a
   verified backup. Applying them by hand in Workbench is how half-migrations happen.
3. Every file is **forward-only**. Rollback lives in `rollback/ROLLBACK_ALL.sql` and
   is not automatic — read its warnings first.
4. Nothing here backfills historical facts. Legacy `NULL` means "not recorded",
   which is a truthful state and is rendered as such in the UI.

---

## 2. Directory contents

| File | Purpose | Executes DDL? | Reversible? |
|---|---|---|---|
| `README.md` | This document: index, order, rules | no | n/a |
| `MIGRATION_PLAN.md` | Full specification, decisions, audit integration, API impact | no | n/a |
| `TEST_MATRIX.md` | Positive/negative test cases (dev DB only) | no | n/a |
| `000_preflight.sql` | Read-only pre-checks and baseline fingerprint | **no** (SELECT only) | n/a |
| `001_user_credential.sql` | F1 — authentication table | yes (CREATE TABLE) | yes, `DROP TABLE` (loses hashes) |
| `002_donation_status_history.sql` | F2 — lifecycle history + legacy snapshots | yes (CREATE + INSERT into the new table) | loses history once written |
| `003_donation_pickup.sql` | F3 — nullable pickup detail columns | yes (ALTER ADD COLUMN) | yes, loses entered addresses |
| `004_delivery_driver_attribution.sql` | F4 — actual driver + planned time + role triggers | yes (ALTER + CREATE TRIGGER) | yes if no attribution recorded |
| `005_donation_item_quantity_guard.sql` | F5 — shrink protection trigger | yes (CREATE TRIGGER) | yes, fully |
| `006_inspection_temperature_check.sql` | F8 — instrument plausibility CHECK | yes (ALTER ADD CHECK) | yes, fully |
| `007_vw_donor_impact.sql` | Donor-impact view (**review-gated**) | yes (CREATE VIEW) | yes, `DROP VIEW` |
| `rollback/ROLLBACK_ALL.sql` | Reverse order, per-object, with warnings | yes | n/a |
| `validation/VALIDATION_ALL.sql` | Post-migration verification queries | **no** (SELECT only) | n/a |

---

## 3. Recommended execution order

```
000 preflight (read-only)
 └─ backup + restore verification
     ├─ 001 user_credential            independent
     ├─ 002 donation_status_history    independent (inserts its own snapshots)
     ├─ 003 donation pickup columns    independent
     ├─ 004 delivery driver + triggers independent
     ├─ 005 donation_item guard        independent
     ├─ 006 temperature CHECK          independent (validates existing rows)
     └─ 007 vw_donor_impact            review-gated, last
```

**Why this order**

- 001–006 have **no interdependencies**; the order is chosen by risk, not by SQL
  dependency: additive tables and nullable columns first, behavioural objects
  (trigger, CHECK) last, so a syntax problem in a trigger cannot leave a
  half-built schema.
- 002 must run **after** 001 only in the deployment script, not in SQL terms —
  the two are unrelated.
- 007 is last and separate because it is a *reporting* object whose numbers must
  be reviewed against the live data before anyone relies on it.
- Nothing depends on `vw_donor_sustainability`, which is preserved untouched.

**Splitting recommendation:** 004 is the only migration worth splitting into
`004a` (columns + FK + indexes) and `004b` (two triggers). A trigger body is the
most likely thing to fail on first execution, and splitting keeps the failure
window to a `CREATE TRIGGER` rather than a partly-applied ALTER.

---

## 4. Rules the eventual runner must enforce

1. Read files in numeric order; **stop at the first error** — never `--force`.
2. Record every applied file in a `schema_migrations` table
   (`version`, `name`, `checksum`, `applied_at`, `applied_by`, `duration_ms`).
   The table is created by the runner's bootstrap, **not** by a migration file,
   and `CREATE TABLE IF NOT EXISTS` is used for it only.
3. Refuse to run if a file's checksum differs from the recorded one.
4. Refuse to run if a precondition query in the file returns a non-zero row
   count (each migration begins with an `-- PRECONDITION` block).
5. Use the `mysql` CLI (or a splitter that understands `DELIMITER`) because
   trigger bodies contain `;`.
6. Credentials come from a local, non-versioned option file
   (`--defaults-extra-file`), never from a command line, source file or chat.
7. After each file: run the matching `V0NN` block in `validation/VALIDATION_ALL.sql`,
   then `database/audit_db.py` against the **migration-aware baseline**
   (see `MIGRATION_PLAN.md` §7 — this needs a small approved change to the audit
   script; until then B.3 will report the new objects as differences, by design).

---

## 5. Backup requirement (before any execution)

```powershell
# Adjust the option file path; do NOT put a password on the command line.
mysqldump --defaults-extra-file="C:\path\to\local.cnf" `
  --single-transaction --routines --triggers --events `
  --set-gtid-purged=OFF --no-tablespaces `
  --result-file="C:\backup\sfc_before_migrations_YYYYMMDD_HHMM.sql" `
  smart_food_supply_chain
```

Then **prove the backup restores**: create a scratch database
`sfc_restore_verify`, restore into it, and run

```powershell
$env:DB_NAME="sfc_restore_verify"; python database/audit_db.py
```

A backup that has never been restored is not a backup. Delete the scratch
database only after the migration is accepted.

---

## 6. What this directory deliberately does **not** contain

- No `DROP DATABASE`, no `TRUNCATE`, no blanket `DELETE`.
- No `ALTER` to an existing constraint or trigger.
- No backfill of `delivery.driver_user_id`.
- No invented pickup addresses, contacts, timestamps or passwords.
- No `CREATE TABLE IF NOT EXISTS` for the new tables (state is verified by the
  precondition queries instead).
- No application code, no data generator, no dev database.
