# PHASE 1 — MIGRATION PLAN

**Status: PREPARATION ONLY.** Nothing in this document has been executed.
Companion files: `README.md` (usage/order), `TEST_MATRIX.md` (tests),
`rollback/ROLLBACK_ALL.sql`, `validation/VALIDATION_ALL.sql`, and the numbered
migration drafts. All are **UNEXECUTED**.

---

## 1. Current state (verified from files and the live audit report)

| Item | Verified value | Source |
|---|---|---|
| Server | MySQL 8.0.46, InnoDB, utf8mb4 / utf8mb4_0900_ai_ci | `audit-report.txt` B.1 |
| Tables | 15 · 86 columns · 40 indexes (incl. 15 primary keys) | B.3 / static parse |
| Views | 2 (`vw_donor_sustainability`, `vw_driver_performance`) | B.4 |
| Triggers | 16 on 8 tables | B.4 |
| CHECK constraints | 6, all `ENFORCED=YES` | B.3 Stage 4 |
| Foreign keys | 25, all `RESTRICT` / `NO ACTION` | B.3 Stage 3 |
| Rows | **104** total (COUNT(*), matches Workbench) | B.2 |
| Schema parity | live == `database/schema.sql`, 0 failures, 0 warnings | B.3 |
| Invariants | 7/7 pass | B.6 |
| Not auditable | `delivery_driver_history` (no column pre-F4) | B.7 |
| Audit exit code | **0** | SUMMARY |

**Row distribution (matters for the legacy-data plan):**

```
organization 3   branch 5   app_user 15   route 5   coverage_area 5
route_assignment 8   donation 5   food_category 8   donation_item 13
inspection_log 5   dependent 6   delivery 5   delivery_item 15
spoilage_record 1   delivery_review 5
```

**Content that the migrations will touch:**

- 5 donations: **4 COMPLETED, 1 APPROVED** → 5 reconstructed history snapshots.
  No `CANCELLED`/`REJECTED` rows, so the new view's exclusion changes no number
  today — it is a correctness guarantee for future data.
- 5 deliveries, **all DELIVERED** → all 5 become `driver_user_id = NULL` and
  `scheduled_for = NULL`. No backfill.
- 5 inspections, all `PASSED`; `temperature_c` currently clean → F8's
  `ALTER ... ADD CHECK` will validate successfully.
- 15 users: 5 DRIVER, 4 DONOR, 3 NGO_MANAGER, 3 SAFETY_INSPECTOR, all ACTIVE.
  8 route assignments = 5 drivers + 3 inspectors (1 inspector unassigned).
  Role split matches the approved 8-row picture, so the assignment invariant
  stays satisfied.
- 5 branches, 3 managers → some manager covers more than one branch; the
  manager scope rule (branch.regional_manager_user_id) already handles this.

### Discrepancies / notes found during inspection

1. **No migration infrastructure exists.** There is no `database/migrations/`,
   no runner, no `schema_migrations`, no `.env`, and **the project is not a git
   repository**. There is therefore no version-control safety net for schema
   changes at the moment. Recommendation: initialise git *before* any migration
   so the drafts, rollbacks and audit reports are committed and reviewable.
2. `database/audit_db.py` hard-codes `SCHEMA_PATH = database/schema.sql`. That
   file is the **pre-migration** baseline, so after any migration the audit's
   structural comparison will correctly report the new objects as differences.
   This is a planned consequence, not a bug — see §7.
3. `audit-report.txt` sits in the project root. It is useful evidence; it should
   be renamed by date (e.g. `reports/audit_2026-11-14_pre-migration.txt`) rather
   than overwritten by the next run.
4. `database/__pycache__/` exists from local compilation of the audit script;
   it is a build artefact, not project content.
5. The Workbench model is `eer diagram.mwb` (23,746 bytes, 15 tables, 0 views).
   It does not model the views or the migrations and will drift from the database
   once migrations are applied. `.mwb` is **not** modified in this phase, and
   must not be treated as the source of truth after migration — the database and
   the migration files are.
6. Nothing proposed here is already implemented: `user_credential`,
   `donation_status_history`, the pickup columns, `driver_user_id`,
   `scheduled_for`, `vw_donor_impact`, `chk_temperature_range` and
   `trg_donation_item_quantity_update` are all absent (preflight P4–P6 proves it).

---

## 2. Migration architecture and order

| # | Migration | Objects | Depends on | Reversible |
|---|---|---|---|---|
| 000 | preflight | read-only checks | — | n/a |
| 001 | `user_credential` | 1 table + FK + unique + 1 CHECK | none | drop table (loses hashes) |
| 002 | `donation_status_history` | 1 table + 2 FK + 3 CHECK + 1 INSERT…SELECT | none | drop table (loses history) |
| 003 | donation pickup | 3 nullable columns | none | drop columns (loses data) |
| 004a | delivery attribution | 2 nullable columns, 2 indexes, 1 FK | none | drop (loses data) |
| 004b | delivery role gate | 2 triggers | 004a | drop triggers — full |
| 005 | item quantity guard | 1 trigger | none | drop trigger — full |
| 006 | temperature CHECK | 1 constraint | none | drop check — full |
| 007 | `vw_donor_impact` | 1 view | none (data shape only) | drop view — full |

Order rationale: additive structure first (001–004a), then behavioural objects
(004b, 005, 006) so a trigger/CHECK failure cannot leave a half-built schema,
then the reporting view last because its numbers must be reviewed before anyone
depends on them. 004 splits into 004a/004b as recommended in `README.md`.

There are **no SQL-level dependencies** between 001, 002, 003, 004a, 005 and 006.
The order is a risk ordering, not a technical one — if a single migration must be
deferred, none of the others break.

---

## 3. Specifications (summary)

Full SQL and per-column commentary live in each numbered file. What follows is
the decision record and the interaction analysis.

### 001 — USER_CREDENTIAL
`user_id` PK/FK → `app_user` (`ON DELETE CASCADE`), `password_hash` (scrypt),
`must_change_password`, `failed_attempts`, `locked_until`, `last_login_at`,
`password_changed_at`, `reset_token_hash` (SHA-256 hex, UNIQUE, many NULLs
allowed), `reset_expires_at`, `created_at`, `updated_at`.
One CHECK: a lock must have been earned (`locked_until IS NULL OR
failed_attempts > 0`).
**No** CHECK on hash format — that would couple the schema to Werkzeug's default
and break a later argon2 move; the service enforces it and the audit already has
`cred_non_scrypt_hash` as an invariant.
Onboarding: **no credentials are created for the 15 existing users.** A manager
issues a single-use activation token; the user sets their own password. Until
then, login fails with the same generic message as a bad password.
Lockout: 5 failures → 15 minutes, doubling to 60; success clears both fields;
per-IP throttling runs alongside so account lockout cannot be abused to deny
service to everyone.

### 002 — DONATION_STATUS_HISTORY
Append-only. `from_status`/`to_status` ENUM (same domain as
`donation.donation_status`), `changed_by_user_id` FK, `changed_at` **nullable by
design**, `is_reconstructed`, `note`.
Three CHECKs: time semantics (`reconstructed ⇔ no timestamp`), no self-transition,
no actor on a reconstructed row.
Legacy: one snapshot per donation — `from_status NULL`, `to_status` = current,
`changed_at NULL`, actor `NULL`, literal note. 5 rows expected.
Writes: one service function per transition, inside one transaction with
`SELECT … FOR UPDATE` on the donation row, then `UPDATE` + `INSERT`. A trigger is
deliberately **not** used because it cannot know the actor.

### 003 — DONATION pickup
`pickup_address VARCHAR(255)`, `pickup_pincode VARCHAR(10)`,
`pickup_contact VARCHAR(15)`, all NULL, no defaults, no backfill.
Format rules live in the API (PIN `^[1-9][0-9]{5}$` after stripping spaces;
contact canonicalised to `+91` + 10 digits starting 6–9). **No DB CHECK** —
addresses are not uniform and a wrong CHECK on a live table is a one-way door;
the optional statement is documented in the file and deferred.
**No index** — no approved query filters on address or PIN yet.
`pickup_datetime` is never used as creation time.

### 004a/004b — DELIVERY attribution
`driver_user_id INT NULL` FK → `app_user`, `scheduled_for DATETIME NULL`,
`idx_delivery_driver_status (driver_user_id, delivery_status)`,
`idx_delivery_scheduled (scheduled_for)`. **No** unique key on
`(donation_id, recipient_branch_id)` — duplicate branch deliveries are approved.
Two triggers mirror `trg_route_driver_*`: the assigned user must hold `DRIVER`.
Account **status** is checked in the service, not the trigger: status changes over
time, and a DB gate would make a suspended driver's rows un-repairable.
Legacy: all 5 rows stay NULL in both columns; UI shows "Not recorded"; confirmed
per-driver totals exclude them; the unconfirmed remainder is reported separately.
Interaction: any UPDATE of a DELIVERED/IN_TRANSIT row re-runs the existing
inspection gate — unchanged behaviour, already satisfied by the baseline data.

**Post-F4 reporting inconsistency (found while reading the view definitions, not
specified in the brief).** `vw_driver_performance` attributes deliveries to a
driver by joining `route.designated_driver_user_id` → `route_id` → `delivery`.
That is *route-based* attribution, not proof of who drove. After 004 the table
will know the actual driver for new rows, while this view keeps crediting the
current designated driver for old ones. Do not silently amend it: keep it as the
legacy route metric, and have the new driver report read `driver_user_id` with
the confirmed/unconfirmed split. Two clearly labelled metrics is honest; one
ambiguous one is not. (Open question 9.)

### 005 — DONATION_ITEM quantity guard
`BEFORE UPDATE` trigger; only when `NEW.quantity_kg < OLD.quantity_kg`; two scalar
subqueries (not joins) for delivered and spoiled; `SIGNAL 45000` if the new
quantity is below their sum. Increases and unrelated edits untouched.
Complements, and does not duplicate, the existing numerator guards; deletion is
already blocked by FK RESTRICT.
Concurrency: every consuming path takes `SELECT … FOR UPDATE` on the
`donation_item` row first, so allocation / spoilage / quantity edit serialise.
The trigger remains the last line of defence.

### 006 — temperature plausibility
`CHECK (temperature_c IS NULL OR (temperature_c BETWEEN -50 AND 150))`.
Inclusive bounds; NULL legal. Instrument plausibility only — `safety_status`
remains the food-safety decision. `ALTER … ADD CHECK` validates existing rows and
fails atomically, hence the hard pre-check.

### 007 — vw_donor_impact (review-gated)
New view beside the existing one, which is preserved unchanged. Verified from the
export: `vw_donor_sustainability.total_distributed_kg` sums **every**
`delivery_item` row regardless of `delivery_status`, so PLANNED, IN_TRANSIT,
FAILED and CANCELLED allocations all count as "distributed". The new view
delivers the corrected definition; the old one keeps its current numbers until
you decide to switch the screens over. CANCELLED
excluded from all three aggregates; delivered counts only `DELIVERED`; spoiled is
its own column; `undistributed_balance_kg` = donated − delivered − spoiled,
labelled an accounting balance, never stock. Pre-aggregated subqueries avoid
fan-out. Review gate in the file: read the numbers against a restored copy first.

---

## 4. Key decisions and why

| Decision | Alternative rejected | Reason |
|---|---|---|
| Separate `user_credential` table | column on `app_user` | Keeps the approved profile table byte-identical; auth data is not profile data and is never selected by profile endpoints. |
| Reset token stored as hash in the credential row | a `password_reset` table, or stateless signed tokens | One extra row-shape instead of a third table; revocable; no server-side secret to rotate. |
| No CHECK on `password_hash` format | `LIKE 'scrypt:%'` | Pins the schema to a library default; blocks an algorithm upgrade. |
| ENUM statuses in history | VARCHAR | Invalid values are rejected by the server; matches the existing `donation` enum. Trade-off: a new status needs two coordinated ALTERs, documented. |
| `changed_at` nullable, no DEFAULT | `DEFAULT CURRENT_TIMESTAMP` | A default would silently timestamp a reconstructed row if the insert omitted the column; with NULL + CHECK, that mistake fails loudly. |
| No DB CHECK on pincode/contact | regex CHECK | Address formats are not uniform; a wrong CHECK needs a live ALTER to relax. |
| No index on pickup columns | speculative index | No approved query uses them; indexes are added with evidence (`EXPLAIN` on 20k rows). |
| Role gate in trigger, status gate in service | both in trigger | Status is mutable over time; a DB gate would block legitimate repair operations. |
| `scheduled_for` included | omit | The manager's planned-delivery and workload screens need it; nullable and never fabricated. |
| No unique on (donation, branch) | unique key | Duplicate branch deliveries are approved. |
| Trigger for quantity guard | service-only rule | Deletion/allocation already enforced in the DB; the remaining hole deserves the same backstop. |
| History written by service, not trigger | AFTER UPDATE trigger | A trigger cannot know the actor; a NULL actor on a real transition is a lie. |

---

## 5. Historical data preservation strategy

| Object | Legacy state | Enforced by |
|---|---|---|
| `user_credential` | no rows; nobody can log in until invited | audit `cred_users_missing` observation |
| `donation_status_history` | 1 reconstructed snapshot, `changed_at NULL`, actor NULL | `chk_dsh_time_semantics`, `chk_dsh_reconstructed_no_actor`, audit `hist_*` invariants |
| `donation.pickup_*` | NULL, rendered "Not recorded" | audit `donation_missing_pickup_address`; API requires values for *new* donations |
| `delivery.driver_user_id` | 5 NULLs, never backfilled | audit `driver_legacy_null`; confirmed/unconfirmed split in B.9 |
| `delivery.scheduled_for` | 5 NULLs | no derivation from `pickup_datetime` |
| Existing tables | 104 rows, unchanged | preflight P8/P9 fingerprints re-checked in V000 |

No migration writes to `organization`, `branch`, `app_user`, `route`,
`coverage_area`, `route_assignment`, `food_category`, `dependent`,
`delivery_review`, `spoilage_record`, `inspection_log` (except the 006 CHECK,
which changes no row), `delivery_item` or `donation_item`. `donation` gains
columns but keeps every existing value.

---

## 6. Rollback limitations

MySQL commits implicitly around DDL, so **no migration here is transactional**.
`rollback/ROLLBACK_ALL.sql` is a compensating script, run deliberately in reverse
order. Key limits:

- 001/002/003/004 drops destroy data created after go-live (hashes, history,
  addresses, driver attribution/schedules). Prefer a forward fix once real data
  exists.
- 005/006/007 are fully reversible: they hold no data.
- A failed `ALTER … ADD CHECK` is atomic per statement, but earlier statements
  in the same batch are already committed. This is why each file is one logical
  change and why the runner stops on first error.
- Restoring from the pre-migration dump is the only true "undo everything",
  and it discards every row written after the backup. Decision point, not a
  routine operation.

---

## 7. Audit integration

`database/audit_db.py` is **not modified in this phase**. Two things must happen
around the migrations, and one needs your approval as a later, reviewed change.

**(a) The baseline problem.** B.3 compares the live schema to
`database/schema.sql`, the frozen pre-migration export. After 001–007 the live
database legitimately contains objects that export does not, so B.3 will report:
1 extra table, 5 extra columns, 2 extra triggers, 1 extra CHECK, 3 extra indexes,
1 extra view — as failures. **This must not be "fixed" by deleting checks or by
editing schema.sql.**

Proposed resolution (needs approval; audit change deferred to the execution
phase): add a `--baseline PATH` argument (default `database/schema.sql`), and
after a successful migration batch produce `database/schema_post_migrations.sql`
with the same `mysqldump --no-data --routines --triggers --events` flags.
Post-migration runs then use `--baseline database/schema_post_migrations.sql` and
the full seven-stage comparison keeps working, against the correct truth. Until
that flag exists, the honest sequence is: run the audit *before* the batch
(expect exit 0), apply, then treat B.3's listed differences as the expected set
and verify each one appears in the migration list exactly once.

**(b) Checks that already exist and will activate automatically.** No code
change is needed for these — they are guarded by object-existence tests and print
`skipped` until the object appears:

| Migration | Existing check | Behaviour after migration |
|---|---|---|
| 001 | `cred_users_missing`, `cred_non_scrypt_hash`, `cred_locked_out` | run; expect 15 missing, 0 non-scrypt, 0 locked |
| 002 | `hist_missing_donation`, `hist_invented_timestamp`, `hist_missing_timestamp`, `hist_duplicate_snapshot` | run; all 0 |
| 003 | `donation_missing_pickup_address` | run; expect 5 |
| 004 | `driver_role_invalid_active`, `driver_legacy_null`, `driver_confirmed_delivered_kg`, `driver_unconfirmed_delivered_kg` | run; expect 5 legacy NULL, 0 confirmed kg, all delivered kg unconfirmed |
| 004 | `delivery_driver_history` | switches from NOT AVAILABLE to a real observation |
| 006 | `temperature_out_of_range` | run; expect 0 |

**(c) New checks worth adding when the audit is next revised** (each is a
read-only query; none weakens an existing check):

| # | Check | Type | Asserts |
|---|---|---|---|
| 1 | `history_status_lag` | INVARIANT | latest `to_status` per donation equals `donation.donation_status` (detects out-of-band UPDATEs) |
| 2 | `cred_must_change_open` | OBSERVATION | users who still owe a password change |
| 3 | `cred_stale_reset_token` | OBSERVATION | token set with `reset_expires_at < NOW()` |
| 4 | `pickup_pincode_suspect` | OBSERVATION | non-NULL values failing the app's format rule |
| 5 | `pickup_contact_suspect` | OBSERVATION | same, for the phone rule |
| 6 | `delivery_transit_without_driver` | INVARIANT | `IN_TRANSIT` with `driver_user_id IS NULL` (new rows only) |
| 7 | `delivery_scheduled_before_pickup` | OBSERVATION | `scheduled_for < donation.pickup_datetime` |
| 8 | `donor_impact_reconciles` | INVARIANT | donated − delivered − spoiled = balance, per donor |
| 9 | `donor_impact_negative_balance` | INVARIANT | no negative balance |

**Unchanged, by explicit instruction:** all 7 current invariants, all 10
observations, the seven-stage structural comparison, the semantic trigger/view
comparison, the inspection-gate self-test and the DONOR-impact preview.

---

## 8. Backend / API impact map

| Migration | Affected endpoints | Behaviour change |
|---|---|---|
| 001 | `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`, `POST /auth/activate`, `POST /auth/password`, `POST /users/{id}/credential-invite` | login requires a credential row; generic failure for missing/bad; session + CSRF; lockout counters; **no response model may contain `password_hash`** |
| 002 | `POST /donations`, `PATCH /donations/{id}/status`, `GET /donations/{id}` (timeline), `GET /donations` (last change) | every status write goes through one transactional function; timeline renders reconstructed nodes distinctly; `APPROVED` requires a PASSED inspection |
| 003 | `POST /donations`, `PATCH /donations/{id}`, `GET /donations/{id}`, driver task cards | pickup address/PIN/contact required on create (422 on omission/invalid); legacy renders "Not recorded"; donor can amend |
| 004 | `POST /deliveries`, `PATCH /deliveries/{id}/driver`, `PATCH /deliveries/{id}/status`, `GET /deliveries`, `GET /reports/drivers` | driver assignment restricted to ACTIVE DRIVERs on the route; `IN_TRANSIT` requires an attributed driver; `scheduled_for` optional but validated; per-driver totals exclude unattributed rows |
| 005 | `POST /deliveries` (allocation), `POST /spoilage`, `PATCH /donation-items/{id}` | 1644 surfaced as 409 "quantity already committed"; allocation locks the item row first |
| 006 | `POST /inspections` | out-of-band temperature rejected as a 422 validation error before SQL; boundary values accepted; message must say "plausibility", not "unsafe" |
| 007 | `GET /reports/donors`, `GET /reports/donors/{id}`, CSV export | new numbers from `vw_donor_impact`; the old view stays available until the switch is reviewed |

Authorization is unchanged by these migrations but newly *enforced* by them:
donor scope (`donor_user_id = me`), manager scope (branches where they are
regional manager), driver scope (routes they are designated for or assigned to),
inspector scope (their branch). Role-change policy P1 is a Phase 3 service
concern; migration 004's triggers only guarantee the DRIVER role at write time.

---

## 9. Execution checklist (Deliverable H)

Order matters. Every step is a decision point, not a formality.

1. **Freeze:** announce a maintenance window; confirm nobody is using Workbench.
2. **Version control:** `git init`, commit the current state, the drafts, and the
   audit report. Migrations without a VCS safety net are not reviewable.
3. **Audit before:** `python database/audit_db.py --out reports/audit_pre.txt`
   → must be exit 0, 7/7 invariants, 104 rows.
4. **Backup:** `mysqldump` with `--single-transaction --routines --triggers
   --events`, to a timestamped file outside the repo.
5. **Restore-verify:** restore into `sfc_restore_verify`, run the audit against
   it (`DB_NAME=sfc_restore_verify`) → exit 0. Only now is the backup real.
6. **Preflight:** run `000_preflight.sql`; require the guard results stated in
   each block (P4/P5/P6 = 0 rows, P10 = 0, P8 = 104).
7. **Apply 001**, run `V001` + audit; record the result.
8. **Apply 002**, run `V002`; confirm exactly 5 snapshots and 0 fabricated
   timestamps.
9. **Apply 003**, run `V003`; confirm 5/5/5 NULL.
10. **Apply 004a**, run the structure part of `V004`; then **004b**, run the
    trigger part.
11. **Apply 005**, run `V005`; confirm the invariant query returns 0.
12. **Apply 006**, run `V006`; confirm ENFORCED=YES and 0 out-of-band readings.
13. **Apply 007 only after** the donor numbers have been reviewed against the
    restore copy (review gate).
14. **Audit after:** with the post-migration baseline (once approved), require
    exit 0 and the expected legacy-NULL counts.
15. **Record:** append every applied version to `schema_migrations`, save the
    pre/post audit reports and validation output together.
16. **Drop `sfc_restore_verify`** only after the batch is accepted.
17. **No application code in this phase.** Phase 2 begins only with explicit
    authorization.

---

## 10. Open questions needing approval

1. **Reset/activation token columns** in `user_credential` (`reset_token_hash`,
   `reset_expires_at`) — keep them, or defer to a separate table?
2. **Lockout numbers** — 5 attempts / 15 min doubling to 60: confirm or specify.
3. **Pincode/contact at DB level** — confirm app-only validation (recommended),
   or add the optional regex CHECKs (test on dev first).
4. **`scheduled_for`** — confirm inclusion (recommended: yes, nullable).
5. **Audit baseline** — approve adding `--baseline` + a post-migration reference
   export in the execution phase. Without it, B.3 will list the new objects as
   differences after every migration.
6. **Driver attribution freeze** — should `driver_user_id` be immutable once
   `DELIVERED` (service rule), with corrections as an explicit manager action?
7. **Item re-parenting** — should moving a `donation_item` to another donation be
   forbidden when allocations exist? Recommended: forbid in the service; a
   trigger is the alternative.
8. **Duplicate branch deliveries** — confirmed allowed; should the allocation
   workspace warn (not block) when a second delivery to the same branch is
   created for one donation?
9. **`vw_driver_performance`** — keep it as the legacy route-based metric and
   add the driver-attributed report alongside (recommended), or replace it once
   attribution data exists?
